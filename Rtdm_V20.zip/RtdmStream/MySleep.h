/*
 * MySleep.h
 *
 *  Created on: Jun 30, 2016
 *      Author: Dave
 */

#ifndef MYSLEEP_H_
#define MYSLEEP_H_

void MySleep (int time);

#endif /* MYSLEEP_H_ */
